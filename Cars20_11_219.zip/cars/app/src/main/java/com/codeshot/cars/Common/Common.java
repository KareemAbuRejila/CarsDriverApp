package com.codeshot.cars.Common;

import com.codeshot.cars.Remote.IGoogleAPI;
import com.codeshot.cars.Remote.RetrofitClient;

public class Common {

    public static final String driversAvailable_tbl="DriversAvailable";
    public static final String drivers_tbl="Drivers";
    public static final String riders_tbl="Riders";
    public static final String pickUpRequest_tbl="PickUpRequests";

    public static final String baseURL="https://maps.googleapis.com";
    public static IGoogleAPI getGoogleAPI(){
        return RetrofitClient.getClient(baseURL).create(IGoogleAPI.class);
    }
}
